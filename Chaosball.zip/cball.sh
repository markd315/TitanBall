export host=ec2-18-223-131-64.us-east-2.compute.amazonaws.com
java -cp Chaosball.jar client.ChaosballWindow